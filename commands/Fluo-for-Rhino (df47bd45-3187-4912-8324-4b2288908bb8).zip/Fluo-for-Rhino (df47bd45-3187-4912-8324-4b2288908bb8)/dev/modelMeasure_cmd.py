import rhinoscriptsyntax as rs

inputMeasure = rs.GetReal("Measure to convert")
if inputMeasure == None:
    exit()


inputScale = rs.GetReal("Scale")
if inputScale == None:
    exit()

coeff = inputScale / 100

realMeasure = coeff * inputMeasure

print(str(realMeasure) + " cm")

